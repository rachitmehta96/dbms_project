package com.example.ebabypp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBabypp2ApplicationTests {

  @Test
  void contextLoads() {
  }

}
