package com.example.ebabypp2.models;

import javax.persistence.*;

@Entity
@Table(name="persons")
public class Person {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String firstName;
  private String lastName;
  private String username;
  private String password;
  private String email;
  //private String birthDate;

  // do we need a default constructor?
  public Person() {

  }
  public Person(String first_name, String last_name, String username, String password, String email) {
    this.username = username;
    this.password = password;
    this.firstName = first_name;
    this.lastName = last_name;
    this.email = email;
  }

  public Integer getId() {
    return id;
  }
  public void setId(Integer newId) {
    this.id = id;
  }
  public String getFirstName() {
    return firstName;
  }
  public void setFirstName(String newFirstName) {
    this.firstName = firstName;
  }
  public String getLastName() {
    return lastName;
  }
  public void setLastName(String newLastName) {
    this.lastName = lastName;
  }
  public String getUsername() {
    return username;
  }
  public void setUsername(String newUserName) {
    this.username = username;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String newPassword) {
    this.password = password;
  }

  public String getEmail() {
    return password;
  }
  public void setEmail(String newEmail) {
    this.password = password;
  }

  // need a getter and setter method for date of birth
}
