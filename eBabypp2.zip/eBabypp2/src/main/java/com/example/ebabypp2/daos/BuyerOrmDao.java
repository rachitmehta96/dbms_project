package com.example.ebabypp2.daos;

import com.example.ebabypp2.models.Buyer;
import com.example.ebabypp2.models.Person;
import com.example.ebabypp2.repositories.BuyerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BuyerOrmDao {
  @Autowired
  BuyerRepository userRepository;
  public Buyer createUser() { return null; }
  public List<Buyer> findAllUser() { return null; }
  public Buyer findBuyerById(Integer id) { return null; }
  //public Integer deleteUser(Integer id) { return null; }
  //public Integer updateUser() { return null; }

  @GetMapping("/orm/buyers/create/{fn}/{ln}/{un}/{pw}")
  public Buyer createBuyer(
          String firstName,
          String lastName,
          String userName,
          String password,
          String email,
          boolean VIP) {
    Person person = new Person(firstName, lastName, userName, password, email);
    Buyer buyer = new Buyer(person.getId(), VIP);
    return userRepository.save(buyer);
  }

}
