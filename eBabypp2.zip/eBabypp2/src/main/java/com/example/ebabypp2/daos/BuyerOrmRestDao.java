package com.example.ebabypp2.daos;

public class BuyerOrmRestDao {

}
