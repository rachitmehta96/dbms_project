package com.example.ebabypp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBabypp2Application {

  public static void main(String[] args) {
    SpringApplication.run(EBabypp2Application.class, args);
  }

}
