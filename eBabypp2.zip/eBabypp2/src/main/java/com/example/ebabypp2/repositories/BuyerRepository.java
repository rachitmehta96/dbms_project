package com.example.ebabypp2.repositories;

import com.example.ebabypp2.models.Buyer;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
public interface BuyerRepository extends CrudRepository<Buyer, Integer>{

  @Query(value = "SELECT * FROM buyers", nativeQuery = true)
  public List<Buyer> findAllBuyers();

  @Query(value = "SELECT * FROM buyers WHERE id=:id", nativeQuery = true)
  public Buyer findBuyerById(@Param("id") Integer id);
}
